# Code by Billal Tech <billal.xcode@gmail.com>

from .G30S import *