class G30SValueError(Exception):
    pass